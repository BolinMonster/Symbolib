package symbolib.expression.functional;

import symbolib.expression.arithmetic.ArithmeticExpression;

/**
 * Cette interface permet de représenter une expression fonctionnelle.
 */
public interface FunctionalExpression extends ArithmeticExpression {
	
}
