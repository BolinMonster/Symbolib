package symbolib.expression.arithmetic;

import symbolib.expression.Expression;

/**
 * Cette interface permet de représenter une expression arithmétique.
 */
public interface ArithmeticExpression extends Expression {
	
}
