package symbolib.expression.rational;

import symbolib.expression.Expression;

/**
 * Interface pour les expressions rationnelles.
*/
public interface RationalExpression extends Expression {
	
}
